/**
 * 
 */
 
$("#button").click(function(){
	
	
	var textVal=encodeURIComponent(document.getElementById("textVal").value);
	var audio = new Audio('PlayAudio?textVal='+textVal);
	audio.controls=true;
	//audio.autoPlay=false;
	document.body.appendChild(audio);
	//audio.play();
 
	 
});

$("#taId").click(function()
{
	var text=$("#toneAnaText").val();
	$.ajax({
		url : 'ToneAnalyzer',
		type : 'POST',
		data : {
			'text' : text
		},
		success : function(result) {
			alert(result);

			

		},
		error : function(jqXHR, textStatus, errorThrown) {
			alert(errorThrown);
		}
	});
	
	
	
	
	

});
