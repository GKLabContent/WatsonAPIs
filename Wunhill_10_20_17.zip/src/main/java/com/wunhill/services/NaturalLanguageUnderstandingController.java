package com.wunhill.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ibm.watson.developer_cloud.natural_language_understanding.v1.NaturalLanguageUnderstanding;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.AnalysisResults;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.AnalyzeOptions;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.CategoriesOptions;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.ConceptsOptions;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.EmotionOptions;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.EntitiesOptions;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.Features;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.KeywordsOptions;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.MetadataOptions;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.RelationsOptions;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.SemanticRolesOptions;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.SentimentOptions;

@Controller
public class NaturalLanguageUnderstandingController {

	static NaturalLanguageUnderstanding service = new NaturalLanguageUnderstanding(
			NaturalLanguageUnderstanding.VERSION_DATE_2017_02_27, "684bc470-babf-44cc-8f64-981d6dad4175",
			"7txKS3LY6XH7");
	
	@ResponseBody
	@RequestMapping(value="/category", method = RequestMethod.POST)
	public String nluCategory(@RequestParam(value="url") String url,Model model){
		NaturalLanguageUnderstanding service = new NaturalLanguageUnderstanding(
				NaturalLanguageUnderstanding.VERSION_DATE_2017_02_27, "684bc470-babf-44cc-8f64-981d6dad4175",
				"7txKS3LY6XH7");

		CategoriesOptions categories = new CategoriesOptions();

		Features features = new Features.Builder()
		  .categories(categories)
		  .build();
		AnalyzeOptions parameters = new AnalyzeOptions.Builder()
				  .url(url)
				  .features(features)
				  .build();

				AnalysisResults response = service
				  .analyze(parameters)
				  .execute();
				System.out.println(response);
		model.addAttribute("resultcategory", response);
		return response+"";
	}
	
	@ResponseBody
	@RequestMapping(value="/concept", method = RequestMethod.POST)
	public String nluComponent(@RequestParam(value="url") String url,Model model){
		NaturalLanguageUnderstanding service = new NaturalLanguageUnderstanding(
				NaturalLanguageUnderstanding.VERSION_DATE_2017_02_27, "2b76b84e-3d08-4760-8ffe-b95bd5c67541",
				"UNFiNeQ6QxHY");

		ConceptsOptions concepts= new ConceptsOptions.Builder()
				  .limit(3)
				  .build();

				Features features = new Features.Builder()
				  .concepts(concepts)
				  .build();

				AnalyzeOptions parameters = new AnalyzeOptions.Builder()
				  .url(url)
				  .features(features)
				  .build();

				AnalysisResults response = service
				  .analyze(parameters)
				  .execute();
				System.out.println(response);
		model.addAttribute("resultconcept", response);
		return response+"";
	}

	@ResponseBody
	@RequestMapping(value="/emotion", method = RequestMethod.POST)
	public String nluEmotion(@RequestParam(value="htmldata") String html,Model model){
		NaturalLanguageUnderstanding service = new NaturalLanguageUnderstanding(
				NaturalLanguageUnderstanding.VERSION_DATE_2017_02_27, "2b76b84e-3d08-4760-8ffe-b95bd5c67541",
				"UNFiNeQ6QxHY");

		List<String> targets = new ArrayList<>();
		targets.add("apples");
		targets.add("oranges");

		EmotionOptions emotion= new EmotionOptions.Builder()
		  .targets(targets)
		  .build();

		Features features = new Features.Builder()
		  .emotion(emotion)
		  .build();

		AnalyzeOptions parameters = new AnalyzeOptions.Builder()
		  .html(html)
		  .features(features)
		  .build();

		AnalysisResults response = service
		  .analyze(parameters)
		  .execute();
		System.out.println(response);		
		model.addAttribute("resultemotion", response);
		return response+"";
	}
	
	@ResponseBody
	@RequestMapping(value="/entity", method = RequestMethod.POST)
	public String nluEntity(@RequestParam(value="url") String url,Model model){
		NaturalLanguageUnderstanding service = new NaturalLanguageUnderstanding(
				NaturalLanguageUnderstanding.VERSION_DATE_2017_02_27, "2b76b84e-3d08-4760-8ffe-b95bd5c67541",
				"UNFiNeQ6QxHY");

		EntitiesOptions entities= new EntitiesOptions.Builder()
				  .sentiment(true)
				  .limit(1)
				  .build();

				Features features = new Features.Builder()
				  .entities(entities)
				  .build();

				AnalyzeOptions parameters = new AnalyzeOptions.Builder()
				  .url(url)
				  .features(features)
				  .build();

				AnalysisResults response = service
				  .analyze(parameters)
				  .execute();
				System.out.println(response);
				model.addAttribute("resultentity", response);
		return response+"";
	}
	
	@ResponseBody
	@RequestMapping(value="/keywords", method = RequestMethod.POST)
	public String nluKeywords(@RequestParam(value="url") String url,Model model){
		NaturalLanguageUnderstanding service = new NaturalLanguageUnderstanding(
				NaturalLanguageUnderstanding.VERSION_DATE_2017_02_27, "2b76b84e-3d08-4760-8ffe-b95bd5c67541",
				"UNFiNeQ6QxHY");

		KeywordsOptions keywords= new KeywordsOptions.Builder()
				  .sentiment(true)
				  .emotion(true)
				  .limit(3)
				  .build();

				Features features = new Features.Builder()
				  .keywords(keywords)
				  .build();

				AnalyzeOptions parameters = new AnalyzeOptions.Builder()
				  .url(url)
				  .features(features)
				  .build();

				AnalysisResults response = service
				  .analyze(parameters)
				  .execute();
				System.out.println(response);
				model.addAttribute("resultkeyword", response);
		return response+"";
	}

	@ResponseBody
	@RequestMapping(value="/metadata", method = RequestMethod.POST)
	public String nluMetadata(@RequestParam(value="url") String url,Model model){
		NaturalLanguageUnderstanding service = new NaturalLanguageUnderstanding(
				NaturalLanguageUnderstanding.VERSION_DATE_2017_02_27, "2b76b84e-3d08-4760-8ffe-b95bd5c67541",
				"UNFiNeQ6QxHY");

		MetadataOptions metadata = new MetadataOptions();
		Features features = new Features.Builder().metadata(metadata).build();
		AnalyzeOptions parameters = new AnalyzeOptions.Builder().url(url).features(features).build();
		AnalysisResults response = service.analyze(parameters).execute();
		System.out.println(response);
		model.addAttribute("resultmetadata", response);
		return response+"";
	}
	
	@ResponseBody
	@RequestMapping(value="/relation", method = RequestMethod.POST)
	public String nluRelation(@RequestParam(value="text") String text,Model model){
		NaturalLanguageUnderstanding service = new NaturalLanguageUnderstanding(
				NaturalLanguageUnderstanding.VERSION_DATE_2017_02_27, "2b76b84e-3d08-4760-8ffe-b95bd5c67541",
				"UNFiNeQ6QxHY");

		RelationsOptions relations = new RelationsOptions.Builder().build();

		Features features = new Features.Builder().relations(relations).build();

		AnalyzeOptions parameters = new AnalyzeOptions.Builder().text(text).features(features).build();

		AnalysisResults response = service.analyze(parameters).execute();
		System.out.println(response);
		model.addAttribute("resultrelation", response);
		return response+"";
	}
	
	@ResponseBody
	@RequestMapping(value="/semanticsroles", method = RequestMethod.POST)
	public String nluSemanticRoles(@RequestParam(value="text") String text,Model model){
		NaturalLanguageUnderstanding service = new NaturalLanguageUnderstanding(
				NaturalLanguageUnderstanding.VERSION_DATE_2017_02_27, "2b76b84e-3d08-4760-8ffe-b95bd5c67541",
				"UNFiNeQ6QxHY");

		SemanticRolesOptions semanticRoles = new SemanticRolesOptions.Builder().build();

		Features features = new Features.Builder().semanticRoles(semanticRoles).build();

		AnalyzeOptions parameters = new AnalyzeOptions.Builder().text(text).features(features).build();

		AnalysisResults response = service.analyze(parameters).execute();
		System.out.println(response);
		model.addAttribute("resultsemanticroles", response);
		return response+"";
	}
	
	@ResponseBody
	@RequestMapping(value="/sentiment", method = RequestMethod.POST)
	public String nluSentiment(@RequestParam(value="url") String url,Model model){
		NaturalLanguageUnderstanding service = new NaturalLanguageUnderstanding(
				NaturalLanguageUnderstanding.VERSION_DATE_2017_02_27, "2b76b84e-3d08-4760-8ffe-b95bd5c67541",
				"UNFiNeQ6QxHY");

		List<String> targets = new ArrayList<String>();
		targets.add("stocks");

		SentimentOptions sentiment = new SentimentOptions.Builder().build();

		Features features = new Features.Builder().sentiment(sentiment).build();

		AnalyzeOptions parameters = new AnalyzeOptions.Builder().url(url).features(features).build();

		AnalysisResults response = service.analyze(parameters).execute();
		System.out.println(response);

		model.addAttribute("resultsentiment", response);
		return response+"";
	}
}
