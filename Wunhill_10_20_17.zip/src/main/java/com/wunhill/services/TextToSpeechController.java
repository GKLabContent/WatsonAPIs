package com.wunhill.services;



import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.ibm.watson.developer_cloud.text_to_speech.v1.TextToSpeech;
import com.ibm.watson.developer_cloud.text_to_speech.v1.model.AudioFormat;
import com.ibm.watson.developer_cloud.text_to_speech.v1.model.Voice;
import com.ibm.watson.developer_cloud.visual_recognition.v3.VisualRecognition;
import com.ibm.watson.developer_cloud.visual_recognition.v3.model.ClassifyImagesOptions;
import com.ibm.watson.developer_cloud.visual_recognition.v3.model.VisualClassification;

/**
 * @author Ranjit Jadhav
 *
 */
@Controller
public class TextToSpeechController {

	
	private static final Logger logger = LoggerFactory
			.getLogger(TextToSpeechController.class);

	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/PlayAudio", method = RequestMethod.GET)
	public void play(ModelAndView model, @RequestParam(value = "textVal") String text, HttpServletResponse res)
			throws IOException {
		System.out.println("inside spring controller" + text);

		TextToSpeech tts = new TextToSpeech();

		tts.setUsernameAndPassword("eea40d05-1d10-4df4-904a-1b34fa034472", "ioOKrOXtLzNf");
		InputStream ins;
		OutputStream out = null;
		Voice voice = tts.getVoice("en-US_AllisonVoice").execute();

		// String format = "audio/ogg; codecs=opus";

		ins = tts.synthesize(text, voice, AudioFormat.WAV).execute();
		// ins=tts.synthesize(text, new Voice(voice, null, null), format);

		res.setContentType("AddType audio/ogg .ogg");
		out = res.getOutputStream();
		byte[] buffer = new byte[2048];
		int read;
		while ((read = ins.read(buffer)) != -1) {
			out.write(buffer, 0, read);
		}
	}

	
}
