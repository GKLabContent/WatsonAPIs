package com.wunhill.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.ibm.watson.developer_cloud.conversation.v1.ConversationService;
import com.ibm.watson.developer_cloud.conversation.v1.model.MessageRequest;
import com.ibm.watson.developer_cloud.conversation.v1.model.MessageResponse;
import com.ibm.watson.developer_cloud.discovery.v1.Discovery;
import com.ibm.watson.developer_cloud.discovery.v1.model.query.QueryRequest;
import com.ibm.watson.developer_cloud.discovery.v1.model.query.QueryResponse;
/**
 * @author Ranjit Jadhav
 *
 */

@Controller
public class ConversationDiscoveryController {
	static MessageResponse response = null;
	
	static Map context = new HashMap();
	
	
	
	@RequestMapping(value = "/chatdiscover", method = RequestMethod.POST)
	public static @ResponseBody String chatdiscover(@RequestParam(value="inp") String input) throws JSONException {
		System.out.println(input);

		System.out.println("Chat Plus Discovery");
	
		response = conversationAPI(input,context); 
	//	System.out.println("Watson Response:"+ response.getText().get(0));
		context = response.getContext();
		
		System.out.println(response.getOutput().get("nodes_visited"));
		String Str = response.getOutput().get("nodes_visited").toString();
		System.out.println("Str " + Str);
		if (Str.equals("[Anything else]")) {
			System.out.println("Go to Discovery");
			
			String res =Discoveryapicall(input);
			//System.out.println("Res  "+res);
			return res;

		}
		
		System.out.println(response.getText().get(0));
		return response.getText().get(0);
	}
	
	
	
	
	public static MessageResponse conversationAPI(String input,Map context){
		
		 ConversationService service = new ConversationService("2017-06-09");
		service.setUsernameAndPassword("e1a390de-d527-4efd-919d-907a362b37ae", "1v55JzIVvmZr");
		MessageRequest newMessage = new MessageRequest.Builder()
		.inputText(input).context(context).build();
		String workspaceId = "f29b329a-d8b4-432a-870a-5b959d6a8dc0";
		MessageResponse response = service.message(workspaceId, newMessage).execute();

		return response;
		} 
	
	public static String Discoveryapicall(String userQuery) throws JSONException{

		 /*String userName = "f56cd48f-8856-446c-abf3-d9879dbdc739";
		 String  password = "SHvmd06Md0Gd";
		 String  collectionId = "2713964f-6c06-4863-a1f2-b524e6cdc27d";
		 String  environmentId = "abb38eae-64c3-47eb-bf53-c8159715c85c";*/
		 
		 String userName = "d9a8e51d-7d6c-4b1d-8949-75e465ec7c74";
		 String password = "qLiMyH72TKus";
		 String collectionId = "375b79f4-a34d-4f8e-be20-1597bc8b2d96";
		 String environmentId = "631b58b4-d507-414d-aedd-40fdb466fd29";
		 
		 Discovery  discovery = new Discovery("2016-12-01");
		 discovery.setEndPoint("https://gateway.watsonplatform.net/discovery/api");
		  discovery.setUsernameAndPassword(userName, password);
		  QueryRequest.Builder queryBuilder = new QueryRequest.Builder(environmentId, collectionId);
		    queryBuilder.query(userQuery);
		   
		    QueryResponse queryResponse = discovery.query(queryBuilder.build()).execute();
		    int size = 1;
		    if(queryResponse.getResults().size()>0){
		    	size = queryResponse.getResults().size();
		    }
		    String fresp[] = new String[size];
		    if(queryResponse.getResults().size()>0){
		    	for(int j = 0;j<size;j++)
		    		//fresp[j] = ""+queryResponse.getResults().get(j).get("value");
		    		fresp[j] = ""+queryResponse.getResults().get(j).get("text");
		    }
		    else{
		    	fresp[0] = "I didn't understand. You can try rephrasing.";
		    }
		    return fresp[0];
	}
	
	

}
