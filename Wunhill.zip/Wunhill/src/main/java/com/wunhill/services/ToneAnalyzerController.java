package com.wunhill.services;



import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.ibm.watson.developer_cloud.tone_analyzer.v3.ToneAnalyzer;
import com.ibm.watson.developer_cloud.tone_analyzer.v3.model.ToneAnalysis;
import com.ibm.watson.developer_cloud.visual_recognition.v3.VisualRecognition;
import com.ibm.watson.developer_cloud.visual_recognition.v3.model.ClassifyImagesOptions;
import com.ibm.watson.developer_cloud.visual_recognition.v3.model.VisualClassification;
import com.rtj.model.ToneAnaPOJO;
import com.rtj.model.Tones;

import net.sf.json.JSON;
import net.sf.json.JSONSerializer;

/**
 * @author Ranjit Jadhav
 *
 */
@Controller
public class ToneAnalyzerController {

	
	private static final Logger logger = LoggerFactory
			.getLogger(ToneAnalyzerController.class);

	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/ToneAnalyzer", method = RequestMethod.GET, produces = "application/String; charset=utf-8")
	public String toneAnalyzer(Model model,
			@RequestParam("textTone") String textTone) {
		System.out.println("textTone "+textTone);
		Gson gson = new Gson();
		ToneAnalyzer service2 = new ToneAnalyzer(ToneAnalyzer.VERSION_DATE_2016_05_19);
		service2.setUsernameAndPassword("49514d92-4b74-41fc-bbaf-84c967f1f8d1", "xZTrNgy7tOWa");

		// String text=textTone;
		ToneAnalysis tone = service2.getTone(textTone, null).execute();
		System.out.println("toneee" + tone);
		List<Tones> emotional = new ArrayList<Tones>();
		List<Tones> language = new ArrayList<Tones>();
		List<Tones> social = new ArrayList<Tones>();
		ToneAnaPOJO tonepojo = gson.fromJson(tone.toString(), ToneAnaPOJO.class);
		// String
		// textFromPojo=tonepojo.getDocument_tone().getTone_categories()[0].getCategory_name();
		Tones[] emotionalTones = tonepojo.getDocument_tone().getTone_categories()[0].getTones();
		Tones[] languageTones = tonepojo.getDocument_tone().getTone_categories()[1].getTones();
		Tones[] socialTones = tonepojo.getDocument_tone().getTone_categories()[2].getTones();
		Map<String, String> finalArray = new HashMap<String, String>();

		emotional = Arrays.asList(emotionalTones);
		language = Arrays.asList(languageTones);
		social = Arrays.asList(socialTones);

		Collections.sort(emotional, new Comparator<Tones>() {

			@Override
			public int compare(Tones o1, Tones o2) {
				// TODO Auto-generated method stub

				if (Float.parseFloat(o1.getScore()) < Float.parseFloat(o2.getScore()))
					return 1;
				if (Float.parseFloat(o1.getScore()) > Float.parseFloat(o2.getScore()))
					return -1;
				return 0;
				// return
				// Integer.parseInt(o1.getScore())-Integer.parseInt(o2.getScore());
			}
		});
		Collections.sort(language, new Comparator<Tones>() {

			@Override
			public int compare(Tones o1, Tones o2) {
				// TODO Auto-generated method stub

				if (Float.parseFloat(o1.getScore()) < Float.parseFloat(o2.getScore()))
					return 1;
				if (Float.parseFloat(o1.getScore()) > Float.parseFloat(o2.getScore()))
					return -1;
				return 0;
				// return
				// Integer.parseInt(o1.getScore())-Integer.parseInt(o2.getScore());
			}
		});
		Collections.sort(social, new Comparator<Tones>() {

			@Override
			public int compare(Tones o1, Tones o2) {
				// TODO Auto-generated method stub

				if (Float.parseFloat(o1.getScore()) < Float.parseFloat(o2.getScore()))
					return 1;
				if (Float.parseFloat(o1.getScore()) > Float.parseFloat(o2.getScore()))
					return -1;
				return 0;
				// return
				// Integer.parseInt(o1.getScore())-Integer.parseInt(o2.getScore());
			}
		});

		model.addAttribute("emotional",  emotional.get(0).getTone_name().toString());
		model.addAttribute("social", social.get(0).getTone_name().toString());
		model.addAttribute("language", language.get(0).getTone_name().toString());
		return "toneanalyzer";
	}


	
}
