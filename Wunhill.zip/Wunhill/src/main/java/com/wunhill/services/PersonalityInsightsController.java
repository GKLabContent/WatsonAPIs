package com.wunhill.services;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

import org.json.JSONException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.stream.JsonReader;
import com.ibm.watson.developer_cloud.personality_insights.v3.PersonalityInsights;
import com.ibm.watson.developer_cloud.personality_insights.v3.model.Content;
import com.ibm.watson.developer_cloud.personality_insights.v3.model.Profile;
import com.ibm.watson.developer_cloud.personality_insights.v3.model.ProfileOptions;
import com.ibm.watson.developer_cloud.util.GsonSingleton;

@Controller
public class PersonalityInsightsController {

	@RequestMapping(value = "/personalityInsights", method = RequestMethod.POST)
	public String personalityInsights(
			@RequestParam("documentAttachment") MultipartFile file, Model model)
			throws RuntimeException, IOException, JSONException {

		PersonalityInsights service = new PersonalityInsights("2016-10-20");
		service.setUsernameAndPassword("1e18caa2-dcf3-4a45-ba3b-2f7beda47041",
				"Y2XjZo8B0Eno");
		String result = null;
		try {
			// JsonReader jReader = new JsonReader(new
			// FileReader("./profile.json"));
			JsonReader jReader = new JsonReader(new FileReader(convert(file)));
			Content content = GsonSingleton.getGson().fromJson(jReader,
					Content.class);
			ProfileOptions options = new ProfileOptions.Builder()
					.contentItems(content.getContentItems())
					.consumptionPreferences(true).rawScores(true).build();
			Profile profile = service.getProfile(options).execute();
			int agreeableness = (int) ((profile.getPersonality().get(3)
					.getPercentile()) * 100);
			int conscientiousness = (int) ((profile.getPersonality().get(1)
					.getPercentile()) * 100);
			int opennessToChange = (int) ((profile.getValues().get(1)
					.getPercentile()) * 100);
			int selfEnhancement = (int) ((profile.getValues().get(3)
					.getPercentile()) * 100);
			/*
			 * System.out.println(profile);
			 * System.out.println("\nAgreeableness:   "+agreeableness);
			 * System.out.println("\nConscientiousness:   "+conscientiousness);
			 * System.out.println("\nOpenness To Change:   "+opennessToChange);
			 * System.out.println("\nSelf-Enhancement:   "+selfEnhancement);
			 */
			result = "\nAgreeableness: " + agreeableness
					+ "\nConscientiousness:   " + conscientiousness
					+ "\nOpenness To Change:   " + opennessToChange
					+ "\nSelf-Enhancement:   " + selfEnhancement;
			// System.out.println(result);
			// model.addAttribute("result", profile);
			model.addAttribute("result", result);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		return "pi";
	}

	public File convert(MultipartFile file) throws IOException {
		File convFile = new File(file.getOriginalFilename());
		convFile.createNewFile();
		FileOutputStream fos = new FileOutputStream(convFile);
		fos.write(file.getBytes());
		fos.close();
		return convFile;
	}

}
