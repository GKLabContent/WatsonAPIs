package com.wunhill.services;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {

	
	private static final Logger logger = LoggerFactory
			.getLogger(HomeController.class);

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		return "home";
	}
	
	@RequestMapping(value = "/VisualRecognition", method = RequestMethod.GET)
	public String VisualRecognition(Locale locale, Model model) {
		
		return "visualrecognition";
	}
	
	@RequestMapping(value = "/ToneAna", method = RequestMethod.GET)
	public String ToneAna(Locale locale, Model model) {
		
		return "toneanalyzer";
	}

	
	@RequestMapping(value = "/Conversation", method = RequestMethod.GET)
	public String Conversation(Locale locale, Model model) {
		
		return "conversation";
	}
	
	
	@RequestMapping(value = "/condiscovery", method = RequestMethod.GET)
	public String condiscovery(Locale locale, Model model) {
		
		return "condiscovery";
	}
	@RequestMapping(value = "/discovery", method = RequestMethod.GET)
	public String discovery(Locale locale, Model model) {
		
		return "discovery";
	}
	
	@RequestMapping(value = "/texttospeech", method = RequestMethod.GET)
	public String texttospeech(Locale locale, Model model) {
		
		return "texttospeech";
	}
	
	@RequestMapping(value = "/document", method = RequestMethod.GET)
	public String documentConversion(Locale locale, Model model) {
		
		return "docConvert";
	}
	
	@RequestMapping(value = "/speechtotext", method = RequestMethod.GET)
	public String speechtotext(Locale locale, Model model) {
		
		return "speechtotext";
	}
	
	@RequestMapping(value = "/languagetranslator", method = RequestMethod.GET)
	public String languagetranslator(Locale locale, Model model) {
		
		return "languagetranslator";
	}
	
	
	@RequestMapping(value = "/nlc", method = RequestMethod.GET)
	public String naturallanguageclassifier(Locale locale, Model model) {
		
		return "nlc";
	}
	
	@RequestMapping(value = "/nlu", method = RequestMethod.GET)
	public String naturallanguageunderstanding(Locale locale, Model model) {
		
		return "nlu";
	}
	
	@RequestMapping(value = "/pi", method = RequestMethod.GET)
	public String pInsights(Locale locale, Model model) {
		
		return "pi";
	}
	
}
