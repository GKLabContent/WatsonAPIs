package com.rtj.model;
public class Tone_categories
{
    private String category_name;

    private Tones[] tones;

    private String category_id;

    public String getCategory_name ()
    {
        return category_name;
    }

    public void setCategory_name (String category_name)
    {
        this.category_name = category_name;
    }

    public Tones[] getTones ()
    {
        return tones;
    }

    public void setTones (Tones[] tones)
    {
        this.tones = tones;
    }

    public String getCategory_id ()
    {
        return category_id;
    }

    public void setCategory_id (String category_id)
    {
        this.category_id = category_id;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [category_name = "+category_name+", tones = "+tones+", category_id = "+category_id+"]";
    }
}
			
			