package com.wunhill.services;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.ibm.watson.developer_cloud.document_conversion.v1.DocumentConversion;

@Controller
public class DocumentConversionController {

	@RequestMapping(value = "/documentConversion", method = RequestMethod.POST)
	public void document(@RequestParam("docFile") MultipartFile file,
			Model model, HttpServletResponse res, HttpServletRequest request) {

		DocumentConversion service = new DocumentConversion("2015-12-15");
		service.setUsernameAndPassword("bd6f0c4c-f17d-490f-8f06-488a5cd65877",
				"MjMAQzrnZ7wZ");

		InputStream ins = null;
		String response = null;
		OutputStream out = null;
		String filename = file.getOriginalFilename();
		int index = filename.indexOf('.');
		String name = filename.substring(0, index);
		try {
			response = service.convertDocumentToHTML(convert(file)).execute();
			// System.out.println(response);
			StringBuffer sb = new StringBuffer(response);
			ins = new ByteArrayInputStream(sb.toString().getBytes("UTF-8"));
			res.setContentType("text/html");
			res.addHeader("Content-Disposition", "attachment; filename=" + name
					+ ".html");
			out = res.getOutputStream();
			byte[] buffer = new byte[2048];
			int read;
			while ((read = ins.read(buffer)) != -1) {
				out.write(buffer, 0, read);
			}
		} catch (RuntimeException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public File convert(MultipartFile file) throws IOException {
		File convFile = new File(file.getOriginalFilename());
		convFile.createNewFile();
		FileOutputStream fos = new FileOutputStream(convFile);
		fos.write(file.getBytes());
		fos.close();
		return convFile;
	}
}
