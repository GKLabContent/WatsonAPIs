package com.wunhill.services;



import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.ibm.watson.developer_cloud.speech_to_text.v1.SpeechToText;
import com.ibm.watson.developer_cloud.speech_to_text.v1.model.RecognizeOptions;
import com.ibm.watson.developer_cloud.speech_to_text.v1.model.SpeechResults;
import com.ibm.watson.developer_cloud.text_to_speech.v1.TextToSpeech;
import com.ibm.watson.developer_cloud.text_to_speech.v1.model.AudioFormat;
import com.ibm.watson.developer_cloud.text_to_speech.v1.model.Voice;
import com.ibm.watson.developer_cloud.visual_recognition.v3.VisualRecognition;
import com.ibm.watson.developer_cloud.visual_recognition.v3.model.ClassifyImagesOptions;
import com.ibm.watson.developer_cloud.visual_recognition.v3.model.VisualClassification;

/**
 * @author Ranjit Jadhav
 *
 */
@Controller
public class SpeechToTextController {

	
	private static final Logger logger = LoggerFactory
			.getLogger(SpeechToTextController.class);

	/**
	 * Simply selects the home view to render by returning its name.
	 */

	
	@RequestMapping(value = "/speechtotext", method = RequestMethod.POST)
	public String spechtotext(@RequestParam("audiofile") MultipartFile file, Model model) throws RuntimeException, IOException, JSONException {
		System.out.println("Inside Speech t text-----" + file);
		SpeechToText service = new SpeechToText();
		service.setUsernameAndPassword("ccce0eb5-d828-48a0-a33a-b7756bb55b5f", "pUfIGstWivRe");


		RecognizeOptions options = new RecognizeOptions.Builder()
		  .contentType("audio/mp3").timestamps(true).interimResults(true)
		  .wordAlternativesThreshold(0.9)
		  .keywords(new String[]{"where", "truck", "my", "know"})
		  .keywordsThreshold(0.5).build();

		System.out.println("Going to work on file...");
		  SpeechResults results = service.recognize(convert(file), options).execute();
		  System.out.println(results);
		  Gson gson = new Gson();
		  String jsonvalue = gson.toJson(results);
			
			JSONObject arr=new JSONObject(jsonvalue);
			
		  System.out.println(results.getResultIndex());
		  
			model.addAttribute("result", results.getResults().get(0).getAlternatives().get(0).getTranscript()); 
		
		return "speechtotext";

	}

	public File convert(MultipartFile file) throws IOException {
		File convFile = new File(file.getOriginalFilename());
		convFile.createNewFile();
		FileOutputStream fos = new FileOutputStream(convFile);
		fos.write(file.getBytes());
		fos.close();
		return convFile;
	}
	
}
