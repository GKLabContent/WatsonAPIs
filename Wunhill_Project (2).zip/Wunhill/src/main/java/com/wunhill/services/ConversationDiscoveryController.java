package com.wunhill.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.ibm.watson.developer_cloud.conversation.v1.ConversationService;
import com.ibm.watson.developer_cloud.conversation.v1.model.MessageRequest;
import com.ibm.watson.developer_cloud.conversation.v1.model.MessageResponse;
import com.ibm.watson.developer_cloud.discovery.v1.Discovery;
import com.ibm.watson.developer_cloud.discovery.v1.model.query.QueryRequest;
import com.ibm.watson.developer_cloud.discovery.v1.model.query.QueryResponse;
/**
 * @author Ranjit Jadhav
 *
 */

@Controller
public class ConversationDiscoveryController {
	static MessageResponse response = null;
	
	static Map context = new HashMap();
	
	
	
	@RequestMapping(value = "/chatdiscover", method = RequestMethod.POST)
	public static @ResponseBody String chatdiscover(@RequestParam(value="inp") String input) throws JSONException {
		System.out.println(input);

		System.out.println("Chat Plus Discovery");
	
		response = conversationAPI(input,context); 
	//	System.out.println("Watson Response:"+ response.getText().get(0));
		context = response.getContext();
		
		System.out.println(response.getOutput().get("nodes_visited"));
		String Str = response.getOutput().get("nodes_visited").toString();
		System.out.println("Str " + Str);
		if (Str.equals("[Anything else]")) {
			System.out.println("Go to Discovery");
			
			String res =Discoveryapicall(input);
			//System.out.println("Res  "+res);
			return res;

		}
		
		System.out.println(response.getText().get(0));
		return response.getText().get(0);
	}
	
	
	
	
	public static MessageResponse conversationAPI(String input,Map context){
		
		 ConversationService service = new ConversationService("2017-06-09");
		service.setUsernameAndPassword("80a79cfa-b27d-4e56-8dc7-0221db74308c", "tUy7FRpwBQlX");
		MessageRequest newMessage = new MessageRequest.Builder()
		.inputText(input).context(context).build();
		String workspaceId = "882de57b-b701-4ce7-b00b-fd5429e607f2";
		MessageResponse response = service.message(workspaceId, newMessage).execute();

		return response;
		} 
	
	public static String Discoveryapicall(String userQuery) throws JSONException{

		 String userName = "f56cd48f-8856-446c-abf3-d9879dbdc739";
		 String  password = "SHvmd06Md0Gd";
		 String  collectionId = "2713964f-6c06-4863-a1f2-b524e6cdc27d";
		 String  environmentId = "abb38eae-64c3-47eb-bf53-c8159715c85c";
		 //String  queryFields = System.getenv("DISCOVERY_QUERY_FIELDS");
		 //String  configurationId="275745c5-11c6-4901-bb95-145ec6771121";
		 Discovery  discovery = new Discovery("2016-12-01");
		 discovery.setEndPoint("https://gateway.watsonplatform.net/discovery/api");
		  discovery.setUsernameAndPassword(userName, password);
		  QueryRequest.Builder queryBuilder = new QueryRequest.Builder(environmentId, collectionId);
		 // StringBuilder sb = new StringBuilder();
		    
		   /* if(queryFields == null || queryFields.length() == 0 || queryFields.equalsIgnoreCase("none")) {
		      sb.append(userQuery);
		    } else {
		      StringTokenizer st = new StringTokenizer(queryFields, ",");
		      while (st.hasMoreTokens()) {
		        sb.append(st.nextToken().trim());
		        sb.append(":");
		        sb.append(userQuery);
		        if (st.hasMoreTokens()) {
		          sb.append(",");
		        }
		      }
		    }*/

		    //queryBuilder.query(sb.toString());
		    queryBuilder.query(userQuery);
		   
		    QueryResponse queryResponse = discovery.query(queryBuilder.build()).execute();
		    //System.out.println("respknkn"+queryResponse.getResults().get(0).get("enriched_text"));
		    //System.out.println(queryResponse);
		   // List<String> li = new ArrayList();
		    int size = 1;
		    if(queryResponse.getResults().size()>0){
		    	size = queryResponse.getResults().size();
		    }
		    String fresp[] = new String[size];
		    //String fresp;
		    if(queryResponse.getResults().size()>0){
		    	for(int j = 0;j<size;j++)
		    		fresp[j] = ""+queryResponse.getResults().get(j).get("value");
		    		//li.add(""+queryResponse.getResults().get(j).get("value"));
		    }
		    else{
		    	fresp[0] = "I didn't understand. You can try rephrasing.";
		    	//li.add("I didn't understand. You can try rephrasing.");
		    }
		
		    
		    
		    
		    
		    
		    
		 /*   Gson gson = new Gson();
			String jsonvalue = gson.toJson(queryResponse.getResults().get(0).get("enriched_text"));
			
			JSONObject arr=new JSONObject(jsonvalue);
			
			JSONArray arrsen=new JSONArray(arr.getString("relations"));
			String fresp="";
		    System.out.println("Resp "+arrsen.length());
		    for (int i = 0; i < arrsen.length(); i++) {
		    	System.out.println("i :: "+arrsen.getJSONObject(i).get("sentence"));
				if(i<4)
				{
					fresp=fresp.concat(i+1+" : "+arrsen.getJSONObject(i).get("sentence").toString() +"\n");
				}
			}*/
	
		//return li.toString();
		    return fresp[0];
	}
	
	

}
