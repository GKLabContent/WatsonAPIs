package com.rtj.model;
public class Tones
{
    private String tone_name;

    private String score;

    private String tone_id;

    public String getTone_name ()
    {
        return tone_name;
    }

    public void setTone_name (String tone_name)
    {
        this.tone_name = tone_name;
    }

    public String getScore ()
    {
        return score;
    }

    public void setScore (String score)
    {
        this.score = score;
    }

    public String getTone_id ()
    {
        return tone_id;
    }

    public void setTone_id (String tone_id)
    {
        this.tone_id = tone_id;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [tone_name = "+tone_name+", score = "+score+", tone_id = "+tone_id+"]";
    }

	public Tones(String tone_name, String score, String tone_id) {
		super();
		this.tone_name = tone_name;
		this.score = score;
		this.tone_id = tone_id;
	}
}
			
			