package com.rtj.model;
public class ToneAnaPOJO
{
    private Document_tone document_tone;

    public Document_tone getDocument_tone ()
    {
        return document_tone;
    }

    public void setDocument_tone (Document_tone document_tone)
    {
        this.document_tone = document_tone;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [document_tone = "+document_tone+"]";
    }
}
		