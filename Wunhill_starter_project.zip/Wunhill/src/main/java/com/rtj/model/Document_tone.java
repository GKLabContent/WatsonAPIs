package com.rtj.model;
public class Document_tone
{
    private Tone_categories[] tone_categories;

    public Tone_categories[] getTone_categories ()
    {
        return tone_categories;
    }

    public void setTone_categories (Tone_categories[] tone_categories)
    {
        this.tone_categories = tone_categories;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [tone_categories = "+tone_categories+"]";
    }
}