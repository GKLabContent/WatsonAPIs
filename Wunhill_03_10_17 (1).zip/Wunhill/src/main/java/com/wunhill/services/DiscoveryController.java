/*package com.wunhill.services;

import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.ibm.watson.developer_cloud.discovery.v1.Discovery;
import com.ibm.watson.developer_cloud.discovery.v1.model.query.QueryRequest;
import com.ibm.watson.developer_cloud.discovery.v1.model.query.QueryResponse;

*/

/**
 * @author Ranjit Jadhav
 *
 *//*

@Controller
public class DiscoveryController {
	
	
	@RequestMapping(value = "/SearchLogistics", method = RequestMethod.GET, produces = "application/String; charset=utf-8")
	public  String showResponse(HttpServletRequest reques, HttpServletResponse response,
			@RequestParam("enterVal") String userQuery, Model mod) {

		String userName = "f56cd48f-8856-446c-abf3-d9879dbdc739";
		String password = "SHvmd06Md0Gd";
		String collectionId = "9082b5f5-863d-419f-94db-e822a38b9150";
		String environmentId = "abb38eae-64c3-47eb-bf53-c8159715c85c";
		String queryFields = System.getenv("DISCOVERY_QUERY_FIELDS");
		String configurationId = "43011602-877e-4cfe-9436-03d8a765b351";
		Discovery discovery = new Discovery("2016-12-01");
		discovery.setEndPoint("https://gateway.watsonplatform.net/discovery/api");
		discovery.setUsernameAndPassword(userName, password);
		QueryRequest.Builder queryBuilder = new QueryRequest.Builder(environmentId, collectionId);
		StringBuilder sb = new StringBuilder();

		if (queryFields == null || queryFields.length() == 0 || queryFields.equalsIgnoreCase("none")) {
			sb.append(userQuery);
		} else {
			StringTokenizer st = new StringTokenizer(queryFields, ",");
			while (st.hasMoreTokens()) {
				sb.append(st.nextToken().trim());
				sb.append(":");
				sb.append(userQuery);
				if (st.hasMoreTokens()) {
					sb.append(",");
				}
			}
		}

		queryBuilder.query(sb.toString());

		QueryResponse queryResponse = discovery.query(queryBuilder.build()).execute();
		System.out.println("respknkn" + queryResponse.getResults().get(0).get("enriched_text"));

		Gson gson = new Gson();
		String jsonvalue = gson.toJson(queryResponse);
		System.out.println("json" + jsonvalue);
		mod.addAttribute("resultfor", userQuery);
		mod.addAttribute("result", jsonvalue);
		return "discovery";
	}

}
*/


package com.wunhill.services;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ibm.watson.developer_cloud.discovery.v1.Discovery;
import com.ibm.watson.developer_cloud.discovery.v1.model.query.QueryRequest;
import com.ibm.watson.developer_cloud.discovery.v1.model.query.QueryResponse;

/**
 * @author Sandeep Kumar
 *
 */

@Controller
public class DiscoveryController {
	
	
	@RequestMapping(value = "/SearchLogistics", method = RequestMethod.GET, produces = "application/String; charset=utf-8")
	public  String showResponse(HttpServletRequest reques, HttpServletResponse response,
			@RequestParam("enterVal") String userQuery, Model mod) {

		/*String userName = "b23dd5ef-acf6-4ed7-ad6d-fb6f2594ce3c";
		String password = "vy0xZlRpACiM";
		String collectionId = "b4a78a84-6cea-4f12-9a3f-cf6d20e18b16";
		String environmentId = "ed19dae9-2fad-4537-8b89-3e07268376d2";*/
		
		String userName = "41dd18b1-1786-4e3e-88b6-c0b0645b2b4f";
		String password = "glKtj8fMp5Ve";
		String collectionId = "caf86e4d-751b-44ab-91ef-b05c5b099640";
		String environmentId = "55658042-7b9c-4558-9b79-611435ad1cdf";
		
		Discovery discovery = new Discovery("2016-12-01");
		discovery.setEndPoint("https://gateway.watsonplatform.net/discovery/api");
		discovery.setUsernameAndPassword(userName, password);
		QueryRequest.Builder queryBuilder = new QueryRequest.Builder(environmentId, collectionId);
		
		queryBuilder.query(userQuery);
		QueryResponse queryResponse = discovery.query(queryBuilder.build()).execute();
		
		if(queryResponse.getResults().size()>0){
			
			String[] jsonvalue = new String[queryResponse.getResults().size()];
			String[] title = new String[queryResponse.getResults().size()];
			for(int i=0;i<(queryResponse.getResults().size());i++){
			 
				//jsonvalue[i] = ""+queryResponse.getResults().get(i).get("value");
				String text = ""+queryResponse.getResults().get(i).get("text");
				//System.out.println(text.substring(9));
				//jsonvalue[i] = ""+queryResponse.getResults().get(i).get("text");
				jsonvalue[i] = text.substring(9);
				//title[i] = ""+queryResponse.getResults().get(i).get("title");
				//System.out.println(queryResponse);
			}
			//System.out.println(jsonvalue.length);
			
			mod.addAttribute("result", jsonvalue);
			//mod.addAttribute("title", title);
			mod.addAttribute("size", jsonvalue.length);
		}
		else{
			mod.addAttribute("result", "No record found!!!");
			mod.addAttribute("title", "");
		}
		mod.addAttribute("resultfor", userQuery);
		return "discovery";
	}

}
